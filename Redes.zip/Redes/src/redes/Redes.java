
package redes;

import java.util.Scanner;
import java.util.Random;

public class Redes {

    public static void main(String[] args) {
     
      
       
       
                
               
                
            
            
            
            if(entrada2 == 2) {
             
                final int Computador2 = 1572531222;
                System.out.println("USTED ESCOGIO EL COMPUTADOR 2 PARA ENVIR EL MENSAJE");
                Hub obj = new Hub();
                obj.enviarMensaje();
                Mensaje obj1 = new Mensaje();
                obj1.contenidoMensaje();
                System.out.println("");
                obj.recibirMensaje();
                Mensaje obj11 = new Mensaje();
                obj1.contenidoMensaje();
                
            }    
                
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
           // }else if(entrada2 == 2) {
             
                final int Computador2 = 1572531222;
                System.out.println("USTED ESCOGIO EL COMPUTADOR 2 PARA ENVIR EL MENSAJE");
                Hub obj = new Hub();
                obj.enviarMensaje();
                Mensaje obj1 = new Mensaje();
                obj1.contenidoMensaje();
                System.out.println("");
                obj.recibirMensaje();
                Mensaje obj11 = new Mensaje();
                obj1.contenidoMensaje();
                
              //  else if (entrada1 == 3){
            
                //final int Computador2 = 1572531231;
                System.out.println("USTED ESCOGIO EL COMPUTADOR 2 PARA ENVIAR EL MENSAJE");
                
  
          }else if(entrada1 != 1){      

              System.out.println("HASTA LUEGO");
        }
    }
}
        
       
        
        
    
    
    
    
