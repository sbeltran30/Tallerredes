
package redes;

import java.util.Random;

public class Hub {
   
    Random Hub = new Random();
    int H = Hub.nextInt(999999);
    final int Computador1 = 1572531221;
    final int Computador2 = 1572531222;
    final int Computador3 = 1572531223;
    final int Computador4 = 1572531224;
    
    public void enviarMensaje(){
    
    System.out.println("Mensaje enviado por computador con IP: " + Computador2);
    System.out.println("Con destino al computador con IP: " +Computador1);
    System.out.println("Con destino al computador con IP: " +Computador3);
    System.out.println("Con destino al computador con IP: " +Computador4);
    
    }
    
    public void recibirMensaje(){
        
    System.out.println("Mensaje recibido por computador con IP: " + Computador1); 
    System.out.println("Mensaje recibido por computador con IP: " + Computador3);
    System.out.println("Mensaje recibido por computador con IP: " + Computador4);
    System.out.println("El mensaje lo envió el computador con IP: "+ Computador2); 
    System.out.println("El mensaje pasó por los siguientes dispositivos: Hub"+H);
    System.out.println("Tiempo total del envio del mensaje: 3 segundos");
    
    }
}

