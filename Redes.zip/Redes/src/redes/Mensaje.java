
package redes;


public class Mensaje {
   
     public void contenidoMensaje(){

    System.out.println("Contenido del mensaje : HOLA ");

    }
    
}

