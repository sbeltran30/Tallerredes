
package redes;

public class Dispositivo {
    
    String id;
    String canalesComunicacion;
    
    Hub obj = new Hub();
    Switch obj1 = new Switch();
    Router obj2 = new Router();
    String  Bridge;
    Repeater obj4 = new Repeater(); 
    
    public void recibirMensaje(){
    
        System.out.println("El mensaje pasó por los siguientes dispositivos:");
     
    }
    
    public void enviarMensaje(){
    
    }
    
}
