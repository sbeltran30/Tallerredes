
package redes;

import java.util.Random;

public class Bridge {
   
    Random Bridge = new Random();
    int B = Bridge.nextInt(999999);
    final int Computador1 = 1572531221;
    final int Computador2 = 1572531222;
    final int Computador3 = 1572531223;
    
    public void enviarMensaje(){
    
    System.out.println("Mensaje enviado por computador con IP: " + Computador1);
    System.out.println("Con destino al computador con IP: " +Computador2);
    System.out.println("Con destino al computador con IP: " +Computador3);
    
    }
    
    public void enviarMensaje2(){
    
    System.out.println("Mensaje enviado por computador con IP: " + Computador2);
    System.out.println("Con destino al computador con IP: " +Computador1);
    System.out.println("Con destino al computador con IP: " +Computador3);
    
    }
    
    public void enviarMensaje3(){
    
    System.out.println("Mensaje enviado por computador con IP: " + Computador3);
    System.out.println("Con destino al computador con IP: " +Computador1);
    System.out.println("Con destino al computador con IP: " +Computador2);
    
    }
    
   
    public void recibirMensaje(){
        
    System.out.println("Mensaje recibido por computador con IP: " + Computador2); 
    System.out.println("Mensaje recibido por computador con IP: " + Computador3); 
    System.out.println("El mensaje lo envió el computador con IP: "+ Computador1); 
    System.out.println("El mensaje pasó por los siguientes dispositivos: Bridge"+B);
    System.out.println("Tiempo total del envio del mensaje: 8 segundos");
    
    }
}
