
package redes;

public class Computador {
    
    String ip;
    int canalComunicacion;
    final int Computador1 = 1572531221;
    final int Computador2 = 1572531222;
    final int Computador3 = 1572531223;
   // final int Computador4 = 1572531251;
   // final int Computador5 = 1572531211;
    
//public void enviarMensaje(){
    
    //System.out.println("Mensaje enviado por computador con IP: " + Computador1);
    //System.out.println("Con destino al computador con IP: " +Computador2);
    //System.out.println("Con destino al computador con IP: " +Computador3);
    //System.out.println("Contenido del mensaje : HOLA ");

//}

//public void recibirMensaje(){

  // System.out.println("Mensaje recibido por computador con IP: " + Computador2); 
   //System.out.println("Mensaje recibido por computador con IP: " + Computador3); 
   //System.out.println("El mensaje lo envió el computador con IP: "+ Computador1); 
   //Bridge obj = new Bridge();
     //       obj.recibirMensaje();
      //      System.out.println("");
   //System.out.println("Contenido del mensaje: Hola: "); 

//}

 public void crearMensaje(){
     
     
     

}

public void leerMensaje(){

}

public void imprimirMensaje(){

    System.out.println("Mensaje enviado por computador con IP: ");
    System.out.println("Con destino al computador con IP: ");
    System.out.println("Contenido del mensaje : HOLA ");
    
}     
 
 



}
    



