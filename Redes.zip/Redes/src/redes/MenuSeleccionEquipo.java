
package redes;

import java.util.Scanner;
import java.util.Random;

import java.util.Scanner;


public class MenuSeleccionEquipo {
    
     int entrada1;
     int entrada2;
     int entrada3;
    
    Scanner variable1 = new Scanner (System.in);
       Scanner variable2 = new Scanner (System.in);
       Scanner variable3 = new Scanner (System.in);
       String palabra1;
       
        System.out.println("DIGITE 1 PARA INICIAR EL SIMULADOR");
        System.out.println("DIGITE 2 PARA SALIR");
        entrada1 = variable1.nextInt();
        System.out.println("");
        
        if (entrada1 == 1) {

            System.out.println("SELECCIONE EL COMPUTADOR DESDE EL QUE SE ENVIARA EL MENSAJE");
            System.out.println("1 - 157.25.31.221");
            System.out.println("2 - 157.25.31.222");
            System.out.println("3 - 157.25.31.223");
            System.out.println("4 - 157.25.31.224");
            System.out.println("5 - 157.25.31.225");
            entrada2 = variable2.nextInt();
            System.out.println("");
            
            System.out.println("SELECCIONE EL DISPOSITIVO POR EL CUAL DESA ENVIAR EL MENSAJE");
            System.out.println("1-BRIDGE");
            System.out.println("2-HUB");
            System.out.println("3-ROUTER");
            System.out.println("4-SWITCH");
            System.out.println("5-REPETER");
            entrada3 = variable3.nextInt();
            System.out.println("");
            
            
            if(entrada2 == 1){
            
                final int Computador1 = 1572531221;
                System.out.println("USTED ESCOGIO EL COMPUTADOR" +entrada2); 
                
                if(entrada3 == 1){
                    
                System.out.println("USTED ESCOGIO EL DISPOSITIVO"+entrada3);System.out.println("BRIDGE");
                Bridge obj = new Bridge();
                obj.enviarMensaje();
                Mensaje obj1 = new Mensaje();
                obj1.contenidoMensaje();
                System.out.println("");
                obj.recibirMensaje();
                Mensaje obj11 = new Mensaje();
                obj1.contenidoMensaje();
                    
                }else if(entrada3 == 2){
                
                System.out.println("USTED ESCOGIO EL DISPOSITIVO"+entrada3);System.out.println("HUB");
                Hub obj = new Hub();
                obj.enviarMensaje();
                Mensaje obj1 = new Mensaje();
                obj1.contenidoMensaje();
                System.out.println("");
                obj.recibirMensaje();
                Mensaje obj11 = new Mensaje();
                obj1.contenidoMensaje();
                
                }else if(entrada3 == 3){
                
                System.out.println("USTED ESCOGIO EL DISPOSITIVO"+entrada3);System.out.println("ROUTER");
                Hub obj = new Hub();
                obj.enviarMensaje();
                Mensaje obj1 = new Mensaje();
                obj1.contenidoMensaje();
                System.out.println("");
                obj.recibirMensaje();
                Mensaje obj11 = new Mensaje();
                obj1.contenidoMensaje();
                
                }else if(entrada3 == 4){
                
                System.out.println("USTED ESCOGIO EL DISPOSITIVO"+entrada3);System.out.println("SWITCH");
                Hub obj = new Hub();
                obj.enviarMensaje();
                Mensaje obj1 = new Mensaje();
                obj1.contenidoMensaje();
                System.out.println("");
                obj.recibirMensaje();
                Mensaje obj11 = new Mensaje();
                obj1.contenidoMensaje();
                
                }else if(entrada3 == 5){
                
                System.out.println("USTED ESCOGIO EL DISPOSITIVO"+entrada3);System.out.println("REPETER");
                Hub obj = new Hub();
                obj.enviarMensaje();
                Mensaje obj1 = new Mensaje();
                obj1.contenidoMensaje();
                System.out.println("");
                obj.recibirMensaje();
                Mensaje obj11 = new Mensaje();
                obj1.contenidoMensaje();
                
                }
                
                
            }else if(entrada1 == 2){
                
                
            
            }
            
            
            
            else if(entrada3 == 2){
                
                final int Computador2 = 1572531222;
                System.out.println("USTED ESCOGIO EL COMPUTADOR" +entrada2); 
                Bridge obj = new Bridge();
                obj.enviarMensaje2();
                Mensaje obj1 = new Mensaje();
                obj1.contenidoMensaje();
                System.out.println("");
                obj.recibirMensaje();
                Mensaje obj11 = new Mensaje();
                obj1.contenidoMensaje();
               
            }else if(entrada3 == 2){
                
                final int Computador3 = 1572531223;
                System.out.println("USTED ESCOGIO EL COMPUTADOR" +entrada2); 
                Bridge obj = new Bridge();
                obj.enviarMensaje3();
                Mensaje obj1 = new Mensaje();
                obj1.contenidoMensaje();
                System.out.println("");
                obj.recibirMensaje();
                Mensaje obj11 = new Mensaje();
                obj1.contenidoMensaje();
               
            }
    
    

