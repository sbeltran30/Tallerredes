/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redes;

/**
 *
 * @author David
 */
public class canalComunicacion {
    
    String id;
    int canal;
    
    public void enviarMensaje(){
    
        Mensaje obj = new Mensaje();
        
    }
    
}
